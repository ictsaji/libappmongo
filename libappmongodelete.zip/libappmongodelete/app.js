

const express=require ('express');

const app=new express ();

const nav=  [       {link:'/home',name:'HOME'},
                    {link:'/books',name:'BOOKS'},
                    {link:'/libsign',name:'SIGNIN'},
                    {link:'/liblog',name:'LOGIN'},
                    {link:'/admin',name:'ADD BOOK'}
            ]

const booksrouter=require('./src/routes/bookroutes')(nav);

const signrouter=require('./src/routes/signroutes')(nav);
const logrouter=require('./src/routes/logroutes')(nav);

const adminrouter=require('./src/routes/adminroutes')(nav);



//app.use(express.urlencoded( {extended:true}));
app.set ('view engine','ejs');

app.set('views','./src/views');

app.use(express.static('./public'));

app.use('/books', booksrouter);
app.use('/libsign', signrouter);
app.use('/liblog', logrouter);
app.use('/admin', adminrouter); //whenever 

app.get('/',function (req,res)
                {  res.render("index.ejs",  
                                {      
                                title:'library',
                                nav

                                } 
                        );  

                }
        );

app.get('/home',function (req,res)
                {  res.render("index.ejs",  
                                {      
                                title:'library',
                                nav

                                } 
                            );  

                }
       );


app.listen(1199);