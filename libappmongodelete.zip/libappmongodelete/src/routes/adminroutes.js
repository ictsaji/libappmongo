const express=require('express');
const adminrouter= express.Router();
const bookdata=require ('../model/bookdata');


function entryroute(nav)
 {


       adminrouter.get('/', function (req, res)
        {
                res.render("addbook",{
                  nav, 
                  title:'library'});
        });

        adminrouter.get('/newbook', function (req, res)
        {
              // res.send( " book added");

               var item= {

               title: req.query.title,
               author: req.query.author,
               genre:req.query.genre,
               image:req.query.image
            }

            var book= bookdata(item);
            book.save();
            res.redirect('/books');

        });

        



        return adminrouter;
}



module.exports = entryroute;
