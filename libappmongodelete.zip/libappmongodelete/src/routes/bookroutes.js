
// basic express import command
const express = require('express');

// access bookdata.js file as well as the data base
const bookdata = require('../model/bookdata');

const booksrouter = express.Router();

function routernav(nav) {


        // var bookss = [

        //         {
        //                 title: 'Rithu',
        //                 author: 'syamaprasad',
        //                 image: "rithu.jpg",
        //                 genre: 'romance'
        //         },

        //         {
        //                 title: 'Neena',
        //                 author: 'laljose',

        //                 image: "neena.jpg",
        //                 genre: 'separation'
        //         },

        //         {
        //                 title: 'Mazha',
        //                 author: 'lenin Rajendran',

        //                 image: "mazha.jpg",
        //                 genre: 'classic'
        //         }


        // ]



        booksrouter.get('/', function (req, res) {

                bookdata.find().then(function (bookss) {
                        res.render("books.ejs",
                                {
                                        nav,
                                        title: 'library',
                                        bookss:bookss
                                });

                });
        });


        booksrouter.get('/:i', function (req, res) {


                const i = req.params.i;

                

                bookdata.findOne({ _id: i }).then(
                        function (book) {
                                res.render('book.ejs', {
                                        nav,
                                        title: 'library',
                                        book

                                });


                        })

        })

        booksrouter.get('/delbook/:d', function (req, res)
        {

            const d = req.params.d;
            console.log(d);

            bookdata.findOneAndDelete({ _id :d})
            .then( function () {
                  res.redirect('/books');


            });

             

        });



        return booksrouter;
}



module.exports = routernav;