const mongoose= require('mongoose');  
//access  the mongoose package


mongoose.connect(  'mongodb://localhost:27017/libdata'); 
            // connect this imported package to mongodb through the port 
            //into database for almirah datatbase of library

const schema=mongoose.Schema;  
// schema definition that is storage format

//new constructor
// title means in ejs page of form filling

const bookschema= new schema (   
    {
             
        title: String,     
        author: String,
        genre: String,
        image: String
    }

);

var bookdata= mongoose.model('bookdb', bookschema); 
// telling the database
                // to store the collection name as in the specified format.
                // bookdata is the planned name, bookshema is the specified schema

module.exports=bookdata; 
// exports all the modules in bookdata to use in other files